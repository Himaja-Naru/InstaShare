import {Component} from 'react'
import LoginForm from '../LoginForm'

class InstaShare extends Component {
  render() {
    return <LoginForm />
  }
}

export default InstaShare
